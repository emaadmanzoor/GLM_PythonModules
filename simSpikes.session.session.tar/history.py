
        # potential update
        V[:,i+1] = V[:,i] + dt*(G_c*(V[:,i]-E_l) - + I_ext[i])/C


    # it is better to have the time steps incorporated
    return(V)

V = simulate_LIF(np.zeros((10,)),np.zeros((10,)),-30,-40,0.1,100)
from numpy import np
import numpy as np
V = simulate_LIF(np.zeros((10,)),np.zeros((10,)),-30,-40,0.1,100)
def simulate_LIF(V0,I_ext,V_th,V_r,dt,nofSteps):

    """ 
        This function simulates the dynamics for LIF with a threshold V_th and
        resting potential V_r with initial condition V0.

        For now just one neuron or many independent neurons.

    """

    # Initializing the potential variable
    N = len(V0)
    V = np.array((N,nofSteps))
    V[:,0] = V0

    # Solving the ODE
    for i in range(nofSteps-1):

        # current update
#        I_g = rowSums(A_g) * V[,i] - A_g %*% V[,i]
 #       I_s = A_s%*%s * V[,i]  - A_s %*% (s*E)

        # synaptic activity update
  #      s = s + dt*(a_r*phi(V[,i],V_eq,beta)*(1-s) - a_d*s)

        # potential update
        V[:,i+1] = V[:,i] + dt*(G_c*(V[:,i]-E_l) - + I_ext[i])/C


    # it is better to have the time steps incorporated
    return(V)

V = simulate_LIF(np.zeros((10,)),np.zeros((10,)),-30,-40,0.1,100)
runfile('/Users/val/MEGAsync/GLM_PythonModules/code/simSpikes_LIF.py', wdir='/Users/val/MEGAsync/GLM_PythonModules/code')
runfile('/Users/val/MEGAsync/GLM_PythonModules/code/untitled1.py', wdir='/Users/val/MEGAsync/GLM_PythonModules/code')
runfile('/Users/val/MEGAsync/GLM_PythonModules/code/simSpikes_LIF.py', wdir='/Users/val/MEGAsync/GLM_PythonModules/code')
V = simulate_LIF(np.zeros((10,)),np.zeros((10,)),-30,-40,0.1,100)
runfile('/Users/val/MEGAsync/GLM_PythonModules/code/simSpikes_LIF.py', wdir='/Users/val/MEGAsync/GLM_PythonModules/code')
V.shape
runfile('/Users/val/MEGAsync/GLM_PythonModules/code/simSpikes_LIF.py', wdir='/Users/val/MEGAsync/GLM_PythonModules/code')
V = simulate_LIF(np.zeros((10,)),np.zeros((10,)),-30,-40,0.1,100)
runfile('/Users/val/MEGAsync/GLM_PythonModules/code/simSpikes_LIF.py', wdir='/Users/val/MEGAsync/GLM_PythonModules/code')
V = simulate_LIF(np.zeros((10,)),np.zeros((10,)),-30,-40,0.1,100)
runfile('/Users/val/MEGAsync/GLM_PythonModules/code/simSpikes_LIF.py', wdir='/Users/val/MEGAsync/GLM_PythonModules/code')
V = simulate_LIF(np.zeros((10,)),np.zeros((10,)),-30,-40,0.1,100)
runfile('/Users/val/MEGAsync/GLM_PythonModules/code/simSpikes_LIF.py', wdir='/Users/val/MEGAsync/GLM_PythonModules/code')
V = simulate_LIF(np.zeros((10,)),np.zeros((10,)),-30,-40,0.1,100)
runfile('/Users/val/MEGAsync/GLM_PythonModules/code/simSpikes_LIF.py', wdir='/Users/val/MEGAsync/GLM_PythonModules/code')
V = simulate_LIF(np.zeros((10,)),np.zeros((10,)),-30,-40,0.1,100)
V = simulate_LIF(-60,np.zeros((10,)),np.zeros((10,)),-30,-40,0.1,100)
V = simulate_LIF(np.zeros((10,)),np.zeros((10,)),-30,-40,0.1,100)
V = simulate_LIF(-60,np.zeros((10,)),np.zeros((10,)),-30,-40,0.1,100)
V = simulate_LIF(-60,np.zeros((10,)),np.zeros((10,)),-30,-40,0.1,100).
runfile('/Users/val/MEGAsync/GLM_PythonModules/code/simSpikes_LIF.py', wdir='/Users/val/MEGAsync/GLM_PythonModules/code')
V = simulate_LIF(-60,np.zeros((10,)),np.zeros((10,)),-30,-40,0.1,100).
V = simulate_LIF(-60,np.zeros((10,)),np.zeros((10,)),-30,-40,0.1,100)
runfile('/Users/val/MEGAsync/GLM_PythonModules/code/simSpikes_LIF.py', wdir='/Users/val/MEGAsync/GLM_PythonModules/code')
V = simulate_LIF(-60,np.zeros((10,)),np.zeros((10,)),-30,-40,0.1,100)
V = simulate_LIF(-60,np.zeros((100,)),np.zeros((10,)),-30,-40,0.1,100)
plot(V[0,:])
plt.plot(V[0,:])
import  matplotlib.pyplot  as plt
plt.plot(V[0,:])
runfile('/Users/val/MEGAsync/GLM_PythonModules/code/simSpikes_LIF.py', wdir='/Users/val/MEGAsync/GLM_PythonModules/code')
plt.plot(V[0,:])
runfile('/Users/val/MEGAsync/GLM_PythonModules/code/simSpikes_LIF.py', wdir='/Users/val/MEGAsync/GLM_PythonModules/code')
plt.plot(V[0,:])
runfile('/Users/val/MEGAsync/GLM_PythonModules/code/simSpikes_LIF.py', wdir='/Users/val/MEGAsync/GLM_PythonModules/code')
plt.plot(V[0,:])
V = simulate_LIF(-60,np.zeros((100,)),np.ones((10,)),-30,-40,0.1,100)
plt.plot(V[0,:])
V = simulate_LIF(-49,np.zeros((100,)),np.ones((10,)),V_th=-50,V_r=-60,0.1,100)
V = simulate_LIF(-49,np.zeros((100,)),np.ones((10,)),V_th=-50,V_r=-60,dt=0.1,nofSteps = 100)
runfile('/Users/val/MEGAsync/GLM_PythonModules/code/simSpikes_LIF.py', wdir='/Users/val/MEGAsync/GLM_PythonModules/code')
V = simulate_LIF(-49,np.zeros((100,)),np.ones((10,)),V_th=-50,V_r=-60,dt=0.1,nofSteps = 100)
runfile('/Users/val/MEGAsync/GLM_PythonModules/code/simSpikes_LIF.py', wdir='/Users/val/MEGAsync/GLM_PythonModules/code')
V = simulate_LIF(-49,np.zeros((100,)),np.ones((10,)),V_th=-50,V_r=-60,dt=0.1,nofSteps = 100)
runfile('/Users/val/MEGAsync/GLM_PythonModules/code/simSpikes_LIF.py', wdir='/Users/val/MEGAsync/GLM_PythonModules/code')
V = simulate_LIF(-49,np.zeros((100,)),np.ones((10,)),V_th=-50,V_r=-60,dt=0.1,nofSteps = 100)
runfile('/Users/val/MEGAsync/GLM_PythonModules/code/simSpikes_LIF.py', wdir='/Users/val/MEGAsync/GLM_PythonModules/code')
V = simulate_LIF(-49,np.zeros((100,)),np.ones((10,)),V_th=-50,V_r=-60,dt=0.1,nofSteps = 100)
plt.plot(V[0,:])
V = simulate_LIF(-49,np.zeros((100,)),np.ones((10,)),V_th=-50,V_r=-60,dt=0.1,nofSteps = 1000)
runfile('/Users/val/MEGAsync/GLM_PythonModules/code/simSpikes_LIF.py', wdir='/Users/val/MEGAsync/GLM_PythonModules/code')
V = simulate_LIF(-49,np.zeros((100,)),np.ones((10,)),V_th=-50,V_r=-60,dt=0.1,nofSteps = 1000)
V = simulate_LIF(-49,np.ones((10,)),V_th=-50,V_r=-60,dt=0.1,nofSteps = 1000)
runfile('/Users/val/MEGAsync/GLM_PythonModules/code/simSpikes_LIF.py', wdir='/Users/val/MEGAsync/GLM_PythonModules/code')
V = simulate_LIF(-49,np.ones((10,)),V_th=-50,V_r=-60,dt=0.1,nofSteps = 1000)
V = simulate_LIF(-49,np.ones((1000,)),V_th=-50,V_r=-60,dt=0.1,nofSteps = 1000)
plt.plot(V[0,:])
V = simulate_LIF(-49,np.ones((1000,)),V_th=-50,V_r=-60,dt=0.01,nofSteps = 1000)
plt.plot(V[0,:])
V = simulate_LIF(-49,np.ones((10000,)),V_th=-50,V_r=-60,dt=0.1,nofSteps = 10000)
plt.plot(V[0,:])
V = simulate_LIF(-49,np.ones((10,)),V_th=-50,V_r=-60,dt=0.1,nofSteps = 10000)
runfile('/Users/val/MEGAsync/GLM_PythonModules/code/simSpikes_LIF.py', wdir='/Users/val/MEGAsync/GLM_PythonModules/code')
V = simulate_LIF(-49,np.ones((10,)),V_th=-50,V_r=-60,dt=0.1,nofSteps = 10000)
V = simulate_LIF()
runfile('/Users/val/MEGAsync/GLM_PythonModules/code/simSpikes_LIF.py', wdir='/Users/val/MEGAsync/GLM_PythonModules/code')
V = simulate_LIF()
V = simulate_LIF(V0 = np.ones(100,))
V = simulate_LIF(V0 = np.ones((100,)))
runfile('/Users/val/MEGAsync/GLM_PythonModules/code/simSpikes_LIF.py', wdir='/Users/val/MEGAsync/GLM_PythonModules/code')
V = simulate_LIF(V0 = np.ones((100,)))
runfile('/Users/val/MEGAsync/GLM_PythonModules/code/simSpikes_LIF.py', wdir='/Users/val/MEGAsync/GLM_PythonModules/code')
V = simulate_LIF(V0 = np.ones((100,)))
runfile('/Users/val/MEGAsync/GLM_PythonModules/code/simSpikes_LIF.py', wdir='/Users/val/MEGAsync/GLM_PythonModules/code')
V = simulate_LIF(V0 = np.ones((100,)))