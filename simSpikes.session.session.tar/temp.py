import numpy as np
import scipy as sp
import matplotlib.pyplot as plt 
import pandas as pd
import random as random
import unittest
from scipy.optimize import minimize
from scipy import stats

# Diffusion Sampling
T = 10 # final time
dt = 0.1 # time step 
# make dt difference in t's
# pass x0
# pass drift as a function
# pass diffusion as a function

def drift(x, param):
        # should be a list of paramters
        # specify it is just a constant
        # returns a data frame 
        # return(np.array(x*param))
        return(np.ones(x.shape)*param)
        
        

    
def diffusion(x):
    # assume parameters are known
    # returns an np.array
    D = np.eye(x.shape[0])
    return(D)


def sampleDiffusion(x0,drift,param,diffusion,dt,T):
# change to allow a starting point different from zero
    
    # N = T/dt; # add case T is not divisible by dt 
    # create an index for 
    index = np.arange(0,T+dt,dt)

    N = index.shape[0]
    x = pd.DataFrame(np.zeros((N,x0.shape[0])),np.array(index))
    x.loc[0] = x0

    i = 1
    for t in index[:-1]:
        # generate random vector
        z = random.normalvariate(np.zeros((x.shape[1],)), np.ones(x.shape[1]))   
        x.iloc[i] = x.loc[t] + dt*drift(x.loc[t],param) + \
        np.sqrt(dt) * np.dot(diffusion(x.loc[t]).T , z)     
        i = i+1
    return(x)    
    
    
def sampleDiffusionBridge(x0,x1,drift,param,diffusion,dt,T):
    # we can do it directly if we have the transition density
    # otherwise need IS formulation
    # test first for Gaussian Bridge

    index = np.arange(0,T+dt,dt)
    N = index.shape[0]
    x = pd.DataFrame(np.zeros((N,x0.shape[0])),np.array(index))

    x.loc[0] = x0
    x.loc[T] = x1 # T+dt
    i = 1
    for t in index[:-1]:
        z = random.normalvariate(np.zeros((x.shape[1],)), np.ones(x.shape[1]))
        x.iloc[i] = x.loc[t] + dt*drift(x.loc[t],param) + \
        dt*(x.loc[T] - x.loc[t])/(T - t) + \
        np.sqrt(dt) * np.dot(diffusion(x.loc[t]).T , z)
        i = i+1
    return(x)
    
    
    
    # Exercise:
    # sample from a diffusion bridge with a drift

# def sampleDiffusionBridge_IS():
     # generate samples from Brownian bridge
     # attach weights based on likelihood ratios
 
 
 # Create a framework for Importance Sampling
 
 # 1) Generate samples - any sort of object
 # 2) Evaluate likelihood of this object

# Store samples in a list
# pass a function to generate a sample
# pass a function which calculates the weight
# 
# class ImportanceSample:
#    def generateObservation():


# create importance sampling function
def generateSample():
    z = random.normalvariate(0,1)
    return(z)
    
def likelihoodRatio(x,param):
    l = stats.expon.pdf(x)/stats.norm.pdf(x)
    return(l)
    
def likelihoodRatio1(x,l1,args1,l2,args2):
    print(l1(x,*args1))
    print(l2(x,*args2))    
    r = l1(x,*args1)/l2(x,*args2)
    return(r)
    
    

# rescale     
def logLikelihood(x,param):
    """ This function tests importance sampling\
        when sampling from centered gaussian \
        to generate a gaussian with a fixed mean
    """
    
    mu = param[0]
    sigma = param[1]
    l1 = np.exp(-(mu - x)**2/(2*sigma*sigma))
    l2 = np.exp(-x**2/(2*sigma*sigma))
    #return(np.log(l1)- np.log(l2))
    return(l1/l2)
    

def importanceSampling_Gaussian(generateSample, logLikelihood, param,N):  
    """ A function implementing importance sampling for a general object.
        [sample, total_weights] = importanceSampling(generateSample, logLikelihood, param,N)
    """
    
    sample = []    
    for i in range(0,N):
        z = generateSample()
        l = logLikelihood(z,param)
        sample.append([z,l])
        
    total_weights = sum([sublist[1] for sublist in sample])
    # normalize the weights
    sample =  [[sublist[0], sublist[1]/total_weights] for sublist in sample]
    return(sample)
 
 
def importanceSampling(generateSample, likelihoodRatio, param,N): 
    sample = []    
    for i in range(0,N):
        z = generateSample()
        l = likelihoodRatio(z,param)
        sample.append([z,l])
        
    total_weights = sum([sublist[1] for sublist in sample])
    # normalize the weights
    sample =  [[sublist[0], sublist[1]/total_weights] for sublist in sample]
    return(sample)
# class importanceSampling:
    
    
    
def importanceSampling1(generateSample, args_generateSample,likelihoodRatio, args_likelihoodRatio,N): 
    sample = []    
    for i in range(0,N):
        z = generateSample(*args_generateSample)
        l = likelihoodRatio(z,*args_likelihoodRatio)
        sample.append([z,l])
        
    total_weights = sum([sublist[1] for sublist in sample])
    # normalize the weights
    sample =  [[sublist[0], sublist[1]/total_weights] for sublist in sample]
    return(sample)
    
    
    
    
    
#     
# def likelihoodRatio(param, data, drift, diffusion, dt):
#    # dt
#    return(dt * drift(data,param) * drift(data))   + diffusion(data)*data.loc[] 
    
def define_l(data, drift, diffusion, dt):
    def l(param):
        data_diff = data.diff().iloc[1::] # makes start from time 2  
        # add the inversion of the diffusion matrices
        ratio = dt * drift(data.iloc[1::],param)*drift(data.iloc[1::],param)/2\
        - drift(data.iloc[1::],param)*np.array(data_diff)
        return(sum(sum(ratio)))
    return l
    
# Diffusion Bridge Sampling

# Parameter Estimation


# Some testing
class TestDiffusionMethods(unittest.TestCase):

    def test_ConstantDrift(self):
    # this function tests the performance with a constant drift and identity diffusion
    # estimating mean of iid Gaussians
    # fix tolerance level?
        def drift(x, param):
            # constant drift
            return(np.ones(x.shape)*param)
        def diffusion(x):
            # assume parameters are known
            # returns an np.array
            D = np.eye(x.shape[0])
            return(D)
            
        dt = 0.01
        T = 10
        theta = 4
        tol = 0.01
        x0 = np.zeros((3,))
        x = sampleDiffusion(x0,drift,theta,diffusion,dt, T)
        l = define_l(x,drift,diffusion,dt)
        theta_hat = minimize(l,0,method = 'Nelder-Mead').x
        error = np.abs(theta_hat - theta_hat)
        # incorporate variance into tolerance      
        self.assertTrue(error < tol)
  
    def test_ConstantDrift_Gaussian(self):
        # discrete
        def drift(x, param):
            # constant drift
            return(np.ones(x.shape)*param)
        def diffusion(x):
            # assume parameters are known
            # returns an np.array
            D = np.eye(x.shape[0])
            return(D)
        dt = 0.01
        T = 10
        theta = 4
        tol = 1
        x0 = np.zeros((3,))
        x = sampleDiffusion(x0,drift,theta,diffusion,dt, T)  
        l = define_l(x,drift,diffusion,dt)
        theta_hat1 = minimize(l,4,method = 'Nelder-Mead').x[0]
        z = np.random.normal(dt*theta, np.sqrt(dt),size = x.shape)
        theta_hat2 = np.mean(z)/dt # vectorize and add covariance      
        error = np.abs(theta_hat1 - theta_hat2)
        self.assertTrue(error<tol)
          
      # test for difference in the first and last position
      # test with a nonconstant drift
      # test with a non identity diffusion matrix
         
      # test sampleDiffusion with a Brownian motion
          
      # include a check for linear parameters and use least squares instead of general optimization
          
      
  
    
      
    def test_BrownianBridge(self):
        def drift(x,param):
            return (np.ones(x.shape)*param)
        def diffusion(x):
            D = np.eye(x.shape[0])
            return(D)
           
        dt = 0.01
        T = 1 # generalize
        theta = 4
        tol = 1
        # run many independently
        n = 10
        x0 = np.zeros((n,))
        x1 = np.zeros((n,)) # pin beginning and end to zero
       
        # generate x through the diffusion equation
        x_diffusion = sampleDiffusionBridge(x0,x1,drift, 0, diffusion,dt,T)
        # generate x directly through the distribution
        # 1) generate Brownian motion
        # w = random.normalvariate(np.zeros())
        w = sampleDiffusion(np.zeros((n,)), drift,0, diffusion, dt,T)
    # 2)        
        index = np.array(w.index)
        x_distribution = w - np.reshape(index, (len(index),1)) * np.reshape(w.loc[T],(1,len(w.loc[T])))
       
        # What is a good way to compare two sets of paths
        # Or compare the paths to the distribution
       
        error = 0 # calculate a real measure
        self.assertTrue(error<tol)
      
       
    # Create functions which measure the goodness of samples in some way
       
    def test_ImportanceSampling_Gaussian(self):
        tol = 1  
        param = [4,1]
        sample = importanceSampling_Gaussian(generateSample,logLikelihood,param,100000)
        mean_estimate = np.sum([sublist[0]*sublist[1] for sublist in sample])
        error = np.abs(mean_estimate - param[0])
        self.assertTrue(error < tol)   
      
    def test_ImportanceSampling_Exponential(self):
        tol = 1
        sample = importanceSampling(generateSample, likelihoodRatio,param,100000)
        mean_estimate = np.sum([sublist[0]*sublist[1] for sublist in sample])
        error = np.abs(mean_estimate - 1)
        self.assertTrue(error < tol)       
      
if __name__ == '__main__':
    unittest.main()
    