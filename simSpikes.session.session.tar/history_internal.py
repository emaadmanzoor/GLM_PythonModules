# -*- coding: utf-8 -*-
# *** Spyder Python Console History Log ***

##---(Sat May 30 22:17:41 2015)---
coeff_h